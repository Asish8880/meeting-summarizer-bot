import google.generativeai as genai

genai.configure(api_key="AIzaSyDEZ50oxRmA8RctqGwtEvnbRtAWnsude_o")

for model in genai.list_models():
    print(model.name)
